---
title: 预祝大家高考顺利！高三课件试题集合！
date:  2020-02-02
tag:
- 高考课件
---

:::tip 
整理到的高考各科练习题以及课件，大家参考一下。预祝高三党前程似锦！

在疫情期间，可以督促一下孩子们努力学习！
:::

**[2020语文课件](https://upload.bcjiangbo.cn/directlink/exam/2020%E8%AF%AD%E6%96%87%E8%AF%BE%E4%BB%B6.zip)**

**[化学复习资料](https://upload.bcjiangbo.cn/directlink/exam/%E5%8C%96%E5%AD%A6%E5%A4%8D%E4%B9%A0%E8%B5%84%E6%96%99.zip)**

**[数学学习资料](https://upload.bcjiangbo.cn/directlink/exam/%E6%95%B0%E5%AD%A6%E5%AD%A6%E4%B9%A0%E8%B5%84%E6%96%99.zip)**

**[物理学习资料1](https://upload.bcjiangbo.cn/directlink/exam/%E7%89%A9%E7%90%86%E5%AD%A6%E4%B9%A0%E8%B5%84%E6%96%991.zip)**

**[物理学习资料2](https://upload.bcjiangbo.cn/directlink/exam/%E7%89%A9%E7%90%86%E5%AD%A6%E4%B9%A0%E8%B5%84%E6%96%992.zip)**

**[生物学习资料](https://upload.bcjiangbo.cn/directlink/exam/%E7%94%9F%E7%89%A9%E5%AD%A6%E4%B9%A0%E8%B5%84%E6%96%99.zip)**

**[英语模拟题](https://upload.bcjiangbo.cn/directlink/exam/%E8%8B%B1%E8%AF%AD%E6%A8%A1%E6%8B%9F%E9%A2%98.DOC)**

**[试题集合](https://upload.bcjiangbo.cn/directlink/exam/%E8%AF%95%E9%A2%98.zip)**
